<?php

namespace App\Http\Controllers\Admin;

use App\Events\Notifications;
use App\Http\Controllers\Controller;
use App\Models\Employee;
use App\Models\EmployeeExperience;
use App\Models\SubMenu;
use App\Models\User;
use App\Models\UserAccess;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;


class EmployeeExperienceController extends Controller
{
    public $parentModel = EmployeeExperience::class;
    public $imagePath = 'images/emp_experience_attachment/';
    public $parentRoute = "employees";
    public $roleRoute =  'employees.index';
    public $menuModel = SubMenu::class;
    public function edit($id = null)
    {
        try{
            $experience = $this->parentModel::where('employee_id', $id)->get();
            return response()->json(['experience' => $experience]);
        }
        catch (\Exception $e){
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }
    public function store(Request $request, $id = null)
    {
        if (!empty($id)) {
            $this->parentModel::role('update_status', $this->roleRoute , null);
        }
        else{
            $this->parentModel::role('create_status', $this->roleRoute , null);
        }
        try {
                $requestData = $request->data;
                parse_str($requestData, $data);
                $data['employee_id'] = $request->employee_id;
                unset($data['_token']);
                unset($data['csrf_token']);

                $employeeData = Employee::where('id', $data['employee_id'])->first();

                foreach ($data['job_title'] as $key => $value) {
                    $fileNames = null;
                    if (!empty($request->file("attachment")[$key])) {
                        $fileNames = str_replace(" ", "", $data['job_title'][$key]) . '_' . time() . '.' . $request->file('attachment')[$key]->getClientOriginalExtension();
                        $request->file('attachment')[$key]->move($this->imagePath, $fileNames);
                    }
                    if($fileNames == null && isset($data['exp_id'][$key]) ){
                        $checkname = $this->parentModel::where('id' , $data['exp_id'][$key] )->first();
                        if(!empty($checkname)){
                            $fileNames = $checkname->attachment;
                        }
                        else{
                            $fileNames = null;
                        }
                    }
                    $exp_id = isset($data['exp_id'][$key]) && !empty($data['exp_id'][$key]) ? $data['exp_id'][$key]: null;
                    $storedata = $this->parentModel::updateOrCreate(['id' => $exp_id], [
                        'employee_id' => $data['employee_id'],
                        'job_title' => $data['job_title'][$key],
                        'attachment' => $fileNames ?? "",
                        'salary' => $data['salary'][$key] ?? 0,
                        'designation' => $data['designation'][$key] ?? "",
                        'start_date' => $data['exp_start_date'][$key],
                        'end_date' => $data['exp_end_date'][$key],
                        'reason_for_leaving' => $data['reason_for_leaving'][$key] ?? "",
                        'description' => $data['description'][$key] ?? "",
                    ]);
                }
                if ($storedata) {
                    $subject = !empty($data['employee_id']) ? 'Employee Experience Information Updated' : 'Employee Experience Information Created';
                    $route = route('employees.details', encrypt($storedata->id));
                    $storeNotification =  $this->parentModel::notification($subject ,  $route  , $storedata->created_at );
                    event(new Notifications($storeNotification));
                    return response()->json(['success' => true]);
                } else {
                    return response()->json(['error' => true]);
                }

        } catch (\Exception $e) {

            return response()->json(['error' => $e->getMessage()]);
        }
    }
    public function delete($id)
    {
        $this->parentModel::role('delete_status',$this->roleRoute,'response');
        try {

                $delete        = $this->parentModel::where('id', $id)->forceDelete();
                if ($delete) {
                    return response()->json(['success' => true]);
                } else {
                    return response()->json(['error' => true]);
                }

        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()]);
        }
    }
    public function get_experience($id){
        $this->parentModel::role('view_status',$this->roleRoute,'response');
        try {

                $qualification        = $this->parentModel::withTrashed()->where('employee_id', $id)->get();
                if ($qualification) {
                    return response()->json(['success' => true , 'data' => $qualification]);
                } else {
                    return response()->json(['error' => true]);
                }

        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()]);
        }
    }

}
